﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
//This class is used to test connection with front end. -Bianca

namespace BackEndAD.Models
{
    public class Stationery
    {
        public int Id { get; set; }
        public string name { get; set; }
        public int quantity { get; set; }
    }
}
